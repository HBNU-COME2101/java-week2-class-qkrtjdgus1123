
public class chapter1_2 {
	public static void main(String [] args) {
		System.out.println("학번: 20242058");
		System.out.println("이름: 박성현");
	}
}